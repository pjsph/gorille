# stereo pan

This applies a set stereo panning to a mono input file. Turning it into a stereo output file with
left/right panning applied per the given panfactor (-1..1)
