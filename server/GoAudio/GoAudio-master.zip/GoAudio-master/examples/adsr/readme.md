# ADSR

This example demonstrates the use of an ADSR (Attack Decay Sustain Release) envelope applies to a
chosen signal.
