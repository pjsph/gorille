# Sine wave

Small program to generate float values for a sine wave

usage:

```
go run main.go > out.txt
// in gnuplot
plot "out.txt" using($1) with lines
```

