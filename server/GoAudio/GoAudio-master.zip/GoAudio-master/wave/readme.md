# GoWave

This library is intended to help me with converting C code from "The Audio Programming Book" into Go
code. The format for the wave file can be found:
https://web.archive.org/web/20141213140451/https://ccrma.stanford.edu/courses/422/projects/WaveFormat/

